import greenfoot.*;
public class border extends block
{
    public void act()
    {
        // Add your action code here.
    }
}
