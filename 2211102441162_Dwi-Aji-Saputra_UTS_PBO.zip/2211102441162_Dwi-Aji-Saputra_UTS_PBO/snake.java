import greenfoot.*;
public class snake extends block
{
    public void act()
    {
        // Add your action code here.
    }
    public snake()
    {
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/10;
        int myNewWidth = (int)myImage.getWidth()/10;
        myImage.scale(myNewWidth, myNewHeight);
        
        
    }
    

}
